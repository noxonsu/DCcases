window.MyDApp_debug = (function(){
  var myDApp = new DCLib.DApp({slug : '01_randomGen_example'})
  return myDApp
})()